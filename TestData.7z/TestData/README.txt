Parameters for testing：

Cross-linker：SDA
fasta File：uniprot-reviewed_yes+AND+organism__Escherichia+coli+(strain+K12)_choose300.fasta
mgf File：uniprot-reviewed_yes+AND+organism__Escherichia+coli+(strain+K12)_choose300_test.mgf
FDR:5%
sFDR:10%
Modifications：None
Enzyme：Trypsin_P
Miss Cleavages：3
Peptide mass range：400-6000
Peptide length range：5-30
MS1/MS2 tolerance：20ppm